
package leeyescarch;

import java.io.*;

/**
 *
 * @author labdessw09
 */
public class Escribir {
    
   
public static void main(String[] args) {
    try {
        String content = "New content to write to file2";

        File file = new File("/home/labdessw09/Documentos/archivo.txt");

        // if file doesnt exists, then create it
        if (!file.exists())
            file.createNewFile();

        FileWriter fw = new FileWriter(file.getAbsoluteFile());
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(content);
        bw.close();

    } catch (IOException e) {
        e.printStackTrace();
    }
}
}
