/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionbd;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.sql.PreparedStatement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author labdessw09
 */
public class agregar {
    
         
    
    public static void main(String[] args) throws SQLException {
    
    
    
    
     Connection conection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
             conection = DriverManager.getConnection("jdbc:mysql://172.17.0.2:3306/Prueba", "root", "root");
             for (int i = 0; i < 10; i++) {
                 //1forma normal 
                 String query = "insert into punto (punto) values("+i+");";
              conection.createStatement().execute(query);
           
              //2prepare statement
            PreparedStatement ps = conection.prepareStatement("insert into punto(punto) values(?)");
            ps.setInt(1, i);
            ps.executeUpdate();
               System.out.println("Conexion exitosa");
            
             
             }
             CallableStatement cs = conection.prepareCall("CALL spInsertarRegistro(?, ?)");
             cs.setInt(1, 100);
             cs.registerOutParameter(2, Types.VARCHAR);
             cs.executeUpdate();
             System.out.println(cs.getString(2));
             System.out.println("ultima conexion");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(agregar.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error de conexion");
        }
               
    }

        
        
        
    }
     
   
    

