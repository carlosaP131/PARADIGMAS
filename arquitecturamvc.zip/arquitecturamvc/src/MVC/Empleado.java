package MVC;


public class Empleado extends Persona implements dominio{
    private float  SalarioEmpleado;
    private String CodigoEmpleado;

    public Empleado() {
    }

    public Empleado(int Idpersona, String Nombre, String NombreUsuario, int Edad, char Sexo, String Contraseña) {
        super(Idpersona, Nombre, NombreUsuario, Edad, Sexo, Contraseña);
    }

    @Override
    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public float getSalarioEmpleado() {
        return SalarioEmpleado;
    }

    public void setSalarioEmpleado(float SalarioEmpleado) {
        this.SalarioEmpleado = SalarioEmpleado;
    }

    public String getCodigoEmpleado() {
        return CodigoEmpleado;
    }

    public void setCodigoEmpleado(String CodigoEmpleado) {
        this.CodigoEmpleado = CodigoEmpleado;
    }

  
    @Override
    public void setId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String cursa() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
