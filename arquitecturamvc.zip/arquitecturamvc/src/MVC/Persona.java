package MVC;


public abstract class Persona {
    private int    Idpersona;
    private String Nombre;
    private String NombreUsuario;
    private int    Edad;
    private char   Sexo;
    private String Contraseña;

    public Persona() {
    }

    public Persona(int Idpersona, String Nombre, String NombreUsuario, int Edad, char Sexo, String Contraseña) {
        this.Idpersona = Idpersona;
        this.Nombre = Nombre;
        this.NombreUsuario = NombreUsuario;
        this.Edad = Edad;
        this.Sexo = Sexo;
        this.Contraseña = Contraseña;
    }
    public abstract String cursa();
    public int getIdpersona() {
        return Idpersona;
    }

    public void setIdpersona(int Idpersona) {
        this.Idpersona = Idpersona;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getNombreUsuario() {
        return NombreUsuario;
    }

    public void setNombreUsuario(String NombreUsuario) {
        this.NombreUsuario = NombreUsuario;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public char getSexo() {
        return Sexo;
    }

    public void setSexo(char Sexo) {
        this.Sexo = Sexo;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String Contraseña) {
        this.Contraseña = Contraseña;
    }

   
}
