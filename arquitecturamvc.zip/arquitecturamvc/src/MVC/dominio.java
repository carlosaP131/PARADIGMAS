package MVC;


public interface dominio {
   public int getId();
   public void setId();
}
