package MVC;


public class ProfesorController  {
    private IProfesorServicio servicio = new ProfesorServicioImpl();

public void crearRegistro(Profesor profesor){
    servicio.crearRegistro(profesor);
   
 }
}
