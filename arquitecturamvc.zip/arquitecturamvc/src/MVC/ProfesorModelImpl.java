package MVC;




public class ProfesorModelImpl implements IProfesormodel{

    @Override
    public void crearRegistro(Profesor profesor) {
        System.out.println("Se creo un Profesro en la base de datos");
    }
      
}
