package MVC;


public class ProfesorServicioImpl implements IProfesorServicio {
    private IProfesormodel modelo = new ProfesorModelImpl();
    @Override
    public void crearRegistro(Profesor profesor) {
        modelo.crearRegistro(profesor);
    
    }
    
}
