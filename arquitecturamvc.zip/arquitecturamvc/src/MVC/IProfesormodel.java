package MVC;


public interface IProfesormodel {
      public void crearRegistro(Profesor profesor);
}
