package MVC;


public class Alumno extends Persona implements dominio{
    private float  BecaAlumno;
    private String MatriculaAlumo;
    public String Nombre;

    public Alumno(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
 
/*
    public Alumno(int Idpersona, String Nombre, String NombreUsuario, int Edad, char Sexo, String Contraseña) {
        super(Idpersona, Nombre, NombreUsuario, Edad, Sexo, Contraseña);
    }

    @Override
    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String cursa() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public float getBecaAlumno() {
        return BecaAlumno;
    }

    public void setBecaAlumno(float BecaAlumno) {
        this.BecaAlumno = BecaAlumno;
    }

    public String getMatriculaAlumo() {
        return MatriculaAlumo;
    }

    public void setMatriculaAlumo(String MatriculaAlumo) {
        this.MatriculaAlumo = MatriculaAlumo;
    }
    */

    @Override
    public String cursa() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
