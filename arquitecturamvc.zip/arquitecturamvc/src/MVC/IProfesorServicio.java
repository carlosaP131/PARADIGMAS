package MVC;


public interface IProfesorServicio {
   public void crearRegistro(Profesor profesor);
}
