package MVC;


public class Profesor extends Persona implements dominio{
    
      private float  SalarioProfesor;
      private int    Claveprofesor;

    public Profesor() {
    }

    public Profesor(int Idpersona, String Nombre, String NombreUsuario, int Edad, char Sexo, String Contraseña) {
        super(Idpersona, Nombre, NombreUsuario, Edad, Sexo, Contraseña);
    }

    public float getSalarioProfesor() {
        return SalarioProfesor;
    }

    public void setSalarioProfesor(float SalarioProfesor) {
        this.SalarioProfesor = SalarioProfesor;
    }

    public int getClaveprofesor() {
        return Claveprofesor;
    }

    public void setClaveprofesor(int Claveprofesor) {
        this.Claveprofesor = Claveprofesor;
    }
  

    @Override
    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String cursa() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
