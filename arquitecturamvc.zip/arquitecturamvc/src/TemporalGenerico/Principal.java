
package TemporalGenerico;

import MVC.Alumno;

public class Principal {
    
    public static void main(String[] args) {
        
            Fruta<Object,Float,String,Alumno>  f1 = new Fruta<Object,Float,String,Alumno>("manzana",6.5f,"roja",new Alumno("Juan"));
            
            System.out.println(f1.getTipo());
            System.err.println(f1.getAlumno().getNombre());
            
    }
}
/*generica
-funciona sobre envoltorio(wrapers)
String,Integer,Float, Double ,Short,
Long , Bolean , Character ,Byte,Object
genericos para clases
 "          "  metodos
     "      "  atributos
E=elemento
K=clave(key)
T=tipo
N=numero
V=valor  

*/
class Fruta <T , V , E,O>{
    private T tipo;
    private V precio;
    private E color;
    private O alumno;
    public  Fruta(T fruta ,V precio,E color, O alumno){
        this.tipo =  fruta;
        this.precio = precio;
        this.color = color;
        this.alumno = alumno; 
    }

    
    public String getTipo(){
        return tipo +"-"+color+"-"+precio+"-"+alumno;
    }
    public Alumno getAlumno(){
        return (Alumno)alumno;
    }
}
class animal {
    
}