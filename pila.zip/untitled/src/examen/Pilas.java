/*
* UNIVERSIDAD DE LA SIERRA SUR
* Autor:Alcántara Pérez Carlos Aurelio
* Fecha Elavoración:17/10/22
*
*
* */
package examen;

import java.util.LinkedList;

public class Pilas<E>{

       //Se crea una lista de tipo LinkedList para ocupar sus metodo predefinidos
        private LinkedList<Pilas>pila = new LinkedList<Pilas>();
       //Objeto de tipo pila para auxiliarme
        Pilas nuevo = new Pilas();
        //Clase que comprueva si la pila es vacia
        public void esvacia(){
                pila.isEmpty();//Usamos el metodo predefinido
        }
        //Elimina el primer elemento
        public void extraer(){
                pila.removeFirst();//Se utiliza este metodo para eliminar solo el primero
        }
        //Obtenemos el primer elemento de la pila
        public Pilas primero(){
                return pila.getFirst();//Se obtiene el primero elemento y lo muestra
        }
        //Añadimos un nuevo elemento
        public void añadir(){

                pila.addFirst(nuevo);//Se amañade un elemento en la primera posición
        }
        //Pasamos a un objeto de tipo String el elemento de la pila
        public String toString(){
                return pila.toString();//Este metodo convierte el elemento en un objeto String
        }

}
