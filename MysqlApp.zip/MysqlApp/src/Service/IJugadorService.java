
package Service;

import Service.base.IRegistroServiceBase;
import entity.Jugador;
import java.util.List;
import javax.swing.JTextField;

public interface IJugadorService extends IRegistroServiceBase<Jugador>{
  

   
}
