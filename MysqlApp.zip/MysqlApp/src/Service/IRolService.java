
package Service;

import Service.base.IRegistroServiceBase;
import entity.Rol;
import java.util.List;
import javax.swing.JTextField;

public interface IRolService extends IRegistroServiceBase<Rol>{
  

   
}
