
package entity.base;

public interface IRegistroEntityBase {
    public int getId();
    public void setId(int id);
    
}
