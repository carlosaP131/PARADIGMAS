
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author epacheco
 */
public class Conexion {
  String pass="estrellaBD";
  String user="root";
  String host="localhost";
  
    public Connection conectaServer(){
      Connection con= null;
       try{
           Class.forName("com.mysql.cj.jdbc.Driver");
           con= DriverManager.getConnection("jdbc:mysql://"+host+"/",user,pass);
           System.out.println("conexión establecida"); 
          
       }catch(Exception ex){
           System.out.println("Error al conectar:"+ ex.getMessage());
       }
        return con;
   }
   
    public Connection conectaBase(String nombrebd){
      Connection con= null;
       try{
           Class.forName("com.mysql.cj.jdbc.Driver");
             con= DriverManager.getConnection("jdbc:mysql://"+host+"/"+nombrebd,user,pass);
           System.out.println("conexión establecida"); 
          
       }catch(Exception ex){
           System.out.println("Error al conectar:"+ ex.getMessage());
       }
        return con;
   }
  
}
