/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import entity.Cliente;
import java.util.List;
import model.CRUD;

/**
 *
 * @author labdessw09
 */
public class service implements iSevice{
    CRUD model = new CRUD();
    @Override
    public void InsertarRegistro(Cliente Registro) {
            model.insetar(Registro);
    }

    @Override
    public List<Cliente> ObtenerRegistro() {
       return model.ObtenerRegistro();
    
    }

    @Override
    public void ActualizarRegistro(Cliente idRegistro) {
        model.ActualizarRegistro(idRegistro);
    }

    @Override
    public void EliminarRegistro(Cliente cliente) {
        model.EliminarRegistro(cliente);
    }
  

}
