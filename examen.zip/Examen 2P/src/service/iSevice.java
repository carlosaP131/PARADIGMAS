/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import entity.Cliente;
import java.util.List;

/**
 *
 * @author labdessw09
 */
public interface iSevice {
    public void InsertarRegistro(Cliente Registro);

    public List<Cliente> ObtenerRegistro();

    public void ActualizarRegistro(Cliente idRegistro);

    public void EliminarRegistro(Cliente cliente);

}
