/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
    
import Conexion.Conexion;
import java.sql.*;

import entity.Cliente;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class CRUD {
    private Conexion conexion;
    private Connection connection;
    private Statement stm;
    
   public void insetar(Cliente cliente) {
       try {
            Conexion conection = new Conexion();
                conection.getConnection();
            String query = "insert into cliente (nombre,apellido) values ('"+cliente.getNombre()+"','"+cliente.getApellido()+"');";
            stm = connection.createStatement();
            stm.execute(query);
            stm.close();
            connection.close();
            
        } catch (SQLException e) {
            System.err.println("error");
        }catch (ClassNotFoundException ex) {
            Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
   
 public List<Cliente> ObtenerRegistro() {
        try {
            List<Cliente> listacliente = new ArrayList<>();
            ResultSet rs;
            conexion = new Conexion();
            connection = conexion.getConnection();
            String query = "call Mostrar;";
            stm = connection.createStatement();
            rs = stm.executeQuery(query);
            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setIdcliente(rs.getInt("idcliente"));
                cliente.setNombre(rs.getString("nombre"));
                cliente.setApellido(rs.getString("apellido"));
            }
            stm.close();
            connection.close();
            return listacliente;
        } catch (SQLException e) {
            System.err.println("Error:");
        }catch (ClassNotFoundException ex) {
            Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
 public void ActualizarRegistro(Cliente clientenuevo) {

        try {

            conexion = new Conexion();
            connection = conexion.getConnection();
            String query = "call Actualizar('"+clientenuevo.getIdcliente()+"','"+clientenuevo.getNombre()+"');";
            ResultSet rs;
            stm = connection.createStatement();
            stm.execute(query);
            
            stm.close();
            connection.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "error");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 public void EliminarRegistro(Cliente cliente) {

        try {

            conexion = new Conexion();//se establece la conexion
            connection = conexion.getConnection();//se obtiene la conexion de la base de datos 
            String query = "call Eliminar('"+cliente.getIdcliente()+"');";
            stm = connection.createStatement();
            stm.execute(query);
            JOptionPane.showMessageDialog(null, "Usuario Eliminado");
            stm.close();
            connection.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "error");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CRUD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
