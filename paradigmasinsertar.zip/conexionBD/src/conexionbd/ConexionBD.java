
package conexionbd;


import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class ConexionBD {

    
    
    public static void main(String[] args) throws SQLException {
       Connection conection = null;
     //  Statement stm = null;
       //busca el driver para conectar ala base de datos 
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
                conection = DriverManager.getConnection("jdbc:mysql://172.17.0.2:3306/Prueba", "root", "root");
               System.out.println("Conexion exitosa");
                String query = "select * from punto";
             Statement stmt = conection.createStatement();
             ResultSet rs = stmt.executeQuery(query);
             while (rs.next()) {
                 System.out.print(rs.getInt("id_punto")+" || ");
                 System.out.println(rs.getInt("punto"));
                
            }
            
        } catch (ClassNotFoundException ex) {
            //Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error de conexion");
        }
    }
    
}
