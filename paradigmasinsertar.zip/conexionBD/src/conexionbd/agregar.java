/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionbd;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author labdessw09
 */
public class agregar {
    
         
    
    public static void main(String[] args) throws SQLException {
    
    
    
    
     Connection conection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
             conection = DriverManager.getConnection("jdbc:mysql://172.17.0.2:3306/Prueba", "root", "root");
             
             //
             String query = "insert into punto (punto) values(2); ";
               conection.createStatement().execute(query);
           
               System.out.println("Conexion exitosa");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(agregar.class.getName()).log(Level.SEVERE, null, ex);
        }
               
    }

        
        
        
    }
     
   
    

