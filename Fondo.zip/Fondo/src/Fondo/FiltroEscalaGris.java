/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fondo;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author labdessw09
 */
public class FiltroEscalaGris {
     public BufferedImage getImagenGrises(String UrlImage) {
        try {
            File Entrada = new File(UrlImage);
            BufferedImage Imageori = ImageIO.read(Entrada);
            BufferedImage imagenbinario = new BufferedImage(Imageori.getWidth(),
                                                            Imageori.getHeight(),
                                                          BufferedImage.TYPE_INT_RGB);
            for (int i = 0; i < Imageori.getHeight(); i++) {
                for (int j = 0; j < Imageori.getWidth(); j++) {
                    //color de una imagen(r,g,b)
                    Color color = new Color(Imageori.getRGB(j, i));
                    int rojo = color.getRed();
                    int verde = color.getGreen();
                    int azul = color.getBlue();
                    int gray = (rojo+verde+azul)/3;  
                            
                   
                    imagenbinario.setRGB(j, i, new Color(gray, gray,gray).getRGB());
                                      
                }
            }
            return imagenbinario;
        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
        }

        return null;

    }
}
