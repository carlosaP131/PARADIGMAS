package Fondo;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

public class CargarArchivo {

    public String getURL() {
        try {
            FileNameExtensionFilter filtro = new FileNameExtensionFilter("jpg png", "jpeg", "jpg", "png");
            JFileChooser chooser = new JFileChooser();
            chooser.setFileFilter(filtro);
            int resultado = chooser.showOpenDialog(null);
            if (JFileChooser.APPROVE_OPTION == resultado) {
                return chooser.getSelectedFile().getPath();
            }
        } catch (Exception e) {
            System.out.println("Error" + e.getMessage());
        }
        return null;
        
    }
    
}
