package Fondo;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author labdessw09
 */
public class FiltroBinario {

    public BufferedImage getImagenBinario(String UrlImage) {
        try {
            File Entrada = new File(UrlImage);
            BufferedImage Imageori = ImageIO.read(Entrada);
            BufferedImage imagenbinario = new BufferedImage(Imageori.getWidth(),
                                                            Imageori.getHeight(),
                                                          BufferedImage.TYPE_BYTE_BINARY);
            for (int i = 0; i < Imageori.getHeight(); i++) {
                for (int j = 0; j < Imageori.getWidth(); j++) {
                    //color de una imagen(r,g,b)
                    Color color = new Color(Imageori.getRGB(j, i));
                    int rojo = color.getRed();
                    int verde = color.getGreen();
                    int azul = color.getBlue();
                    int humbral = 127;
                    rojo = (rojo>humbral)? 255:0;
                    verde = (verde>humbral)? 255:0;
                    azul = (verde>humbral)? 255:0;
                    imagenbinario.setRGB(j, i, new Color(rojo, verde,azul).getRGB());
                    
//                    if(rojo>humbral)
//                        rojo=255;
//                    else
//                        rojo=0;
//                  
                }
            }
            return imagenbinario;
        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
        }

        return null;

    }
}
