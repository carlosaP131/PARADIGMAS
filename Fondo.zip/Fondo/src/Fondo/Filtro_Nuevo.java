/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fondo;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author labdessw09
 */
public class Filtro_Nuevo {
    public BufferedImage getImagenNuevo(String UrlImage) {
        try {
            File Entrada = new File(UrlImage);
            BufferedImage Imageori = ImageIO.read(Entrada);
            BufferedImage imagennuevo = new BufferedImage(Imageori.getWidth(),
                                                            Imageori.getHeight(),
                                                          BufferedImage.TYPE_INT_RGB);
            for (int i = 0; i < Imageori.getHeight(); i++) {
                for (int j = 0; j < Imageori.getWidth(); j++) {
                    //color de una imagen(r,g,b)
                    Color color = new Color(Imageori.getRGB(j, i));
                    int rojo = color.getRed();
                    int verde = color.getGreen();
                    int azul = color.getBlue();
                   
                    
                    imagennuevo.setRGB(j, i, new Color(255-rojo, 255-verde,255-azul).getRGB());
                    
//                    if(rojo>humbral)
//                        rojo=255;
//                    else
//                        rojo=0;
//                  
                }
            }
            return imagennuevo;
        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
        }

        return null;

    }
}
