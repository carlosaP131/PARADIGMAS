/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fondo;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author labdessw09
 */
public class FiltroCambioColor {
        public BufferedImage getCambioColor(String UrlImage) {
        try {
            File Entrada = new File(UrlImage);
            BufferedImage Imageori = ImageIO.read(Entrada);
            BufferedImage imagencolor = new BufferedImage(Imageori.getWidth(),
                                                            Imageori.getHeight(),
                                                          BufferedImage.TYPE_INT_RGB);
            for (int i = 0; i < Imageori.getHeight(); i++) {
                for (int j = 0; j < Imageori.getWidth(); j++) {
                    //color de una imagen(r,g,b)
                    int color = Imageori.getRGB(j, i);
                   
                   
                    imagencolor.setRGB(j, i, color - 150);
                                      
                }
            }
            return imagencolor;
        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
        }

        return null;

    }
}
