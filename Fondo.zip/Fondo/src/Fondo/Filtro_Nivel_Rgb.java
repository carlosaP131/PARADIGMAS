
package Fondo;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author labdessw09
 */
public class Filtro_Nivel_Rgb {
     public BufferedImage getImagennivelRgb(String UrlImage,int sR,int sV,int sA) {
        try {
            File Entrada = new File(UrlImage);
            BufferedImage Imageori = ImageIO.read(Entrada);
            BufferedImage imagenNivelRgb = new BufferedImage(Imageori.getWidth(),
                                                            Imageori.getHeight(),
                                                          BufferedImage.TYPE_INT_RGB);
            for (int i = 0; i < Imageori.getHeight(); i++) {
                for (int j = 0; j < Imageori.getWidth(); j++) {
                    //color de una imagen(r,g,b)
                    Color color = new Color(Imageori.getRGB(j, i));
                    int rojo = color.getRed();
                    int verde = color.getGreen();
                    int azul = color.getBlue();
                    rojo =  rojo+rojo*sR/100;
                    verde =  verde+verde*sV/100;
                    azul =  azul+azul*sA/100;
                    if (rojo>255)
                        rojo = 255;
                    if (rojo<0)
                        rojo = 0;
                    if (verde>255)
                        verde = 255;
                    if (verde<0)
                        verde = 0;
                    if (azul>255)
                        azul = 255;
                    if (azul<0)
                        azul = 0;
                    
                        
                    
                    imagenNivelRgb.setRGB(j, i, new Color(rojo, verde,azul).getRGB());
                    
//                    if(rojo>humbral)
//                        rojo=255;
//                    else
//                        rojo=0;
//                  
                }
            }
            return imagenNivelRgb;
        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
        }

        return null;

    }
}
