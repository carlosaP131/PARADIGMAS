/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fondo;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import javax.imageio.ImageIO;

/**
 *
 * @author labdessw09
 */
public class DescargarPixelIMagen {
     public void getPixel(BufferedImage Imagen,String Salida) {
        try {
            String path = "src/"+Salida;
            File Entrada = new File(path);
            if (!Entrada.exists()) {
                Entrada.createNewFile();
            }
            FileWriter FileWriter = new FileWriter(Entrada);
            BufferedWriter bw = new BufferedWriter(FileWriter);
            
            
            for (int i = 0; i < Imagen.getHeight(); i++) {
                for (int j = 0; j < Imagen.getWidth(); j++) {
                    //color de una imagen(r,g,b)
                    Color color = new Color(Imagen.getRGB(j, i));
                    int rojo = color.getRed();
                    int verde = color.getGreen();
                    int azul = color.getBlue();
                   
                        bw.write("("+rojo+","+verde+","+azul+")");
                    
//                    if(rojo>humbral)
//                        rojo=255;
//                    else
//                        rojo=0;
//                  
                }
                bw.write("\n");
            }
            
        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
        }

     

    }
}
