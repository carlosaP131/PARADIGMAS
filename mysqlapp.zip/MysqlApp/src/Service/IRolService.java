
package Service;

import entity.Rol;
import java.util.List;
import javax.swing.JTextField;

public interface IRolService {
  public void InsertarRegistro(Rol rol);
public List<Rol> ObtenerRegistro(); 
public void ActualizarRegistro(Rol idrol,Rol rolnuevo);
public void EliminarRegistro(Rol rol);
 public Rol BuscarRegistro(int id);

   
}
