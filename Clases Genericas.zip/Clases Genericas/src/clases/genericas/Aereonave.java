
package clases.genericas;



public abstract class Aereonave<E> {
    public E Numid;
    public int NumMotores;
    public int Tripulacion;
    public String Fabricante;
    public String Nombre;

    public E getNumid() {
        return Numid;
    }

    public void setNumid(E Numid) {
        this.Numid = Numid;
    }

    public int getNumMotores() {
        return NumMotores;
    }

    public void setNumMotores(int NumMotores) {
        this.NumMotores = NumMotores;
    }

    public int getTripulacion() {
        return Tripulacion;
    }

    public void setTripulacion(int Tripulacion) {
        this.Tripulacion = Tripulacion;
    }

    public String getFabricante() {
        return Fabricante;
    }

    public void setFabricante(String Fabricante) {
        this.Fabricante = Fabricante;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
     

  
    
    
}
