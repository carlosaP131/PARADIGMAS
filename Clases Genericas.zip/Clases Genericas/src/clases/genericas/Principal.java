/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases.genericas;

/**
 *
 * @author carlos
 */
public class Principal {
    public static void main(String[] args) {
               Avion avion = new Avion();
               Helicoptero heli = new Helicoptero();
               
         avion.setNumid(1);//aqui se palica la lase generica con la herencia 
         avion.setFabricante("North American");
         avion.setNumMotores(1);
         avion.setTipo("Caza");
         avion.setTripulacion(1);
         avion.setNombre("P-51 Mustang");
         System.out.println("Id: "+avion.getNumid()+"\nNombre: "+avion.getNombre()+
                 "\nTipo: "+avion.getTipo()+"\nNo. Motores: "+avion.getNumMotores()+
                 "\nFabricante: "+ avion.getFabricante()+"\nNo. Tripulacion: "+avion.getTripulacion());       
   
        heli.setNumid("AH-8723");//aqui se palica la lase generica con la herencia 
        heli.setFabricante("Boeing");
        heli.setNumMotores(2);
        heli.setNumhelices(8);
        heli.setTripulacion(2);
        heli.setNombre("AH-64");
     System.out.println("Id: "+heli.getNumid()+"\nNombre: "+heli.getNombre()+
                 "\nNo. Helices: "+heli.getNumhelices()+"\nNo. Motores: "+heli.getNumMotores()+
                 "\nFabricante: "+ heli.getFabricante()+"\nNo. Tripulacion: "+heli.getTripulacion()); 
    }
}
