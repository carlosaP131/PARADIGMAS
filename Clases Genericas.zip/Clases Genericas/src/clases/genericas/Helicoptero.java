/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases.genericas;

/**
 *
 * @author carlos
 */
public class Helicoptero extends Aereonave<String>{
     public int Numhelices;

    public Helicoptero(int Numhelices) {
        this.Numhelices = Numhelices;
    }

    public Helicoptero() {
    }

    public int getNumhelices() {
        return Numhelices;
    }

    public void setNumhelices(int Numhelices) {
        this.Numhelices = Numhelices;
    }

    public String getNumid() {
        return Numid;
    }

    public void setNumid(String Numid) {
        this.Numid = Numid;
    }

    public int getNumMotores() {
        return NumMotores;
    }

    public void setNumMotores(int NumMotores) {
        this.NumMotores = NumMotores;
    }

    public int getTripulacion() {
        return Tripulacion;
    }

    public void setTripulacion(int Tripulacion) {
        this.Tripulacion = Tripulacion;
    }

    public String getFabricante() {
        return Fabricante;
    }

    public void setFabricante(String Fabricante) {
        this.Fabricante = Fabricante;
    }
     
}
