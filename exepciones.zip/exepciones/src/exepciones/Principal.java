/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exepciones;

import exception.Carga;
import exception.Conejo;
import exception.Correcaminos;
import exception.Tortuga;

public class Principal {

    public static void main(String[] args) {

        Caballo caballo = new Caballo();
        Tortuga tortuga = new Tortuga();
        Animal conejo = new Conejo();
        Animal correcaminos = new Correcaminos();
        Carga carga = new Carga(20);
        caballo.setNombre("Moro");
        caballo.setCodigo("20-f1");
        caballo.setVelocidad(10);
        
        tortuga.setNombre("Billi");
        tortuga.setVelocidad(2);
        tortuga.setCodigo("31-f3");
        conejo.setNombre("Esponjoso");
        conejo.setVelocidad(23);
        conejo.setCodigo("221-f3");
        correcaminos.setNombre("Sully");
        correcaminos.setVelocidad(40);
        correcaminos.setCodigo("23-f4");
        System.out.println(caballo.toString());
        System.out.println(tortuga.toString());
        System.out.println(conejo.toString());
        System.out.println(correcaminos.toString());

    }
}
