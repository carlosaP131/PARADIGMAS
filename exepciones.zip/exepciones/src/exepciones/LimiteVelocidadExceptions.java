package exception;

public class LimiteVelocidadExceptions extends Exception{

    public LimiteVelocidadExceptions() {
    }

    public LimiteVelocidadExceptions(String message) {
        super(message);
    }  
    
}
