
package exception;


public class Carga {
    
    private double peso;

    public Carga(double peso) {
        this.peso = peso;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "carga: " + peso + " kilogramos";
    }
    
    
    
}
