
package javaapplication1;

import java.util.Scanner;
public class JavaApplication1{
    public static void main(String[] args) {
        int i;
        int suma = 0;
        int n;
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un número: ");
        n = sc.nextInt();
        for (i = 1; i < n; i++) {                              
            if (n % i == 0) {
                suma = suma + i;  
            }
        }
        if (suma == n) {                         
            System.out.println("El numero es Perfecto");
        } else {
            System.out.println("El numero no es perfecto");

        }
    }
}