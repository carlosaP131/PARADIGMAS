
package exepciones;


public class Limite_Velocidad_exepcion extends Exception {

    public Limite_Velocidad_exepcion() {
    }

    public Limite_Velocidad_exepcion(String message) {
        super(message);
    }
    
}