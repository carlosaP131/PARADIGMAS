/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases.genericas;

/**
 *
 * @author carlos
 */
public class Avion extends Aereonave<Integer>{
    public String Tipo;

    public Avion(String Tipo) {
        this.Tipo = Tipo;
    }

    public Avion() {
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public Integer getNumid() {
        return Numid;
    }

    public void setNumid(Integer Numid) {
        this.Numid = Numid;
    }

    public int getNumMotores() {
        return NumMotores;
    }

    public void setNumMotores(int NumMotores) {
        this.NumMotores = NumMotores;
    }

    public int getTripulacion() {
        return Tripulacion;
    }

    public void setTripulacion(int Tripulacion) {
        this.Tripulacion = Tripulacion;
    }

    public String getFabricante() {
        return Fabricante;
    }

    public void setFabricante(String Fabricante) {
        this.Fabricante = Fabricante;
    }

   
    
}
